<?php
$name = $_POST['fio'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$other = $_POST['other'];
$name = htmlspecialchars($name);
$email = htmlspecialchars($email);
$phone = htmlspecialchars($phone);
$other = htmlspecialchars($other);
$name = urldecode($name);
$email = urldecode($email);
$phone = urldecode($phone);
$other = urldecode($other);
$name = trim($name);
$email = trim($email);
$phone = trim($phone);
$other = trim($other);
//echo $name;
//echo "<br>";
//echo $email;
if (mail("SlavarenikFlance@gmail.com", "Заявка с сайта", "ФИО:".$name.". E-mail: ".$email." Phone: ". $phone . "Other: " . $other ,"From: example2@mail.ru \r\n"))
{     echo "сообщение успешно отправлено";
} else {
    echo "при отправке сообщения возникли ошибки";
}?>